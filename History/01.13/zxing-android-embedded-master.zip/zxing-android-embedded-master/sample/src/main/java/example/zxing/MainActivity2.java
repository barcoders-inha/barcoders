package example.zxing;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    private EditText ad_et;
    private Button ad_login;
    private Button ad_return;
    private String str;
    String str2 = "Administrator";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ad_return = findViewById(R.id.ad_return);
        ad_et = findViewById(R.id.ad_et);
        ad_login = findViewById(R.id.ad_login);
        ad_login.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                str = ad_et.getText().toString();
                Intent intent = new Intent(MainActivity2.this, AdActivity.class);
                startActivity(intent); // 암호키 설정해야하는 부분.

            }
        });

        ad_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent (MainActivity2.this,MainActivity.class);
                startActivity(intent1);
            }
        });


    }
}