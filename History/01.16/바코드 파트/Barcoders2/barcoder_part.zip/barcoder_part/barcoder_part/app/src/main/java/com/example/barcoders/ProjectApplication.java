package com.example.barcoders;

import android.app.Application;

public class ProjectApplication extends Application {
}
