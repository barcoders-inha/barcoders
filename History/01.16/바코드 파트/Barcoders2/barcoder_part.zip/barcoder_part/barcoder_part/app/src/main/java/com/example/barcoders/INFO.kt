package com.example.barcoders

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class INFO : AppCompatActivity (){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.info)

    }
}