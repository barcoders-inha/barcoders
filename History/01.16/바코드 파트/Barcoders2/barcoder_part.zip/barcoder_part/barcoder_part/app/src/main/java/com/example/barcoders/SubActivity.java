package com.example.barcoders;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        List<Barcode> ItemList = initLoadBarcodeDatabase();

        String num = getIntent().getStringExtra("number"); //바코드 식별번호 String으로 바꿔서 넣어야함
        String[] arr = addItem(ItemList, num);

    }


    public List<Barcode> initLoadBarcodeDatabase(){
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        databaseHelper.OpenDatabaseFile();

        List<Barcode> ItemList = databaseHelper.getTableData();
        Log.e("test", String.valueOf(ItemList.size()));

        databaseHelper.close();

        return ItemList;
    }

    public String[] addItem(List<Barcode> ItemList, String num) {


        String[] arr = {"item","material"};

        for (int i = 0; i < ItemList.size(); i++) {

            if (num.equals(ItemList.get(i).getBarcode())) {
                arr[0] = ItemList.get(i).getItem();
                arr[1] = ItemList.get(i).getMaterial();
                if (arr[1]=="metal"){
                    Intent intent = new Intent(SubActivity.this,Success_metal.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }
                else if (arr[1]=="paper"){
                    Intent intent = new Intent(SubActivity.this,Success_paper.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }
                else if (arr[1]=="poly"){
                    Intent intent = new Intent(SubActivity.this,Success_poly.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }
                else if (arr[1]=="glass"){
                    Intent intent = new Intent(SubActivity.this,Success_glass.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }
                else if (arr[1]=="vinyl"){
                    Intent intent = new Intent(SubActivity.this,Success_vinyl.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }
                else if (arr[1]=="plastic"){
                    Intent intent = new Intent(SubActivity.this,Success_plastic.class);
                    intent.putExtra("name",arr[0]);
                    intent.putExtra("material",arr[1]);
                    startActivity(intent);
                }

                break;
            }

        }
        return arr;
    }

}
