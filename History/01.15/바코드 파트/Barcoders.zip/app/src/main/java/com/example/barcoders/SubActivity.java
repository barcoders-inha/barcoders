package com.example.barcoders;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class SubActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        List<Barcode> ItemList = initLoadBarcodeDatabase();

        String[] arr = addItem(ItemList);

        TextView textView = (TextView) findViewById(R.id.text);
        textView.setText(arr[0] + "\n" + arr[1]);


    }


    public List<Barcode> initLoadBarcodeDatabase(){
        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
        databaseHelper.OpenDatabaseFile();

        List<Barcode> ItemList = databaseHelper.getTableData();

        databaseHelper.close();

        return ItemList;
    }

    public String[] addItem(List<Barcode> ItemList) {

        String tmp = "8801007150338";

        String[] arr = {"item","material"};

        for (int i = 0; i < ItemList.size(); i++) {

            if (tmp.equals(ItemList.get(i).getBarcode())) {
                arr[0] = ItemList.get(i).getItem();
                arr[1] = ItemList.get(i).getMaterial();
                break;
            }

        }
        return arr;
    }

}
